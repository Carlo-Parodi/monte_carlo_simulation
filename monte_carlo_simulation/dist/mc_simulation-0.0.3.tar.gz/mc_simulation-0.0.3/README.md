# mc_simulation
This library allows you to run Monte Carlo simulations on time series
